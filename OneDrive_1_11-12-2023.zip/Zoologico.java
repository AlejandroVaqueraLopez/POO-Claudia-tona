public class Zoologico{

    private List<Animal> animales;

    public Zoologico() {
        animales = new ArrayList<>();
    }

    public void agregarAnimal(Animal animal) {
        animales.add(animal);
    }

    public void consultarAnimales() {
        for(Animal animal : animales) {
            System.out.println(animal.getNombre() + " " + animal.getTamanio() + " "+ animal.getPeso() + " " + animal.getVelocidad() + " " + animal.getDieta());
        }
    }
}