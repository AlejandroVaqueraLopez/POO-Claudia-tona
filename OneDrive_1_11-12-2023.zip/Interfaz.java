public interface Animal{
    public String getNombre();

    public int getTamanio();

    public int getPeso();

    public int getVelocidad();

    public String getDieta();
}

public class Leon implements Animal {
    private String nombre;
    private int tamanio;
    private int peso;
    private int velocidad;
    private String dieta;

    public Leon(String nombre, int tamanio, int peso, int velocidad, String dieta) {
        this.nombre = nombre;
        this.tamanio = tamanio;
        this.peso = peso;
        this.velocidad = velocidad;
        this.dieta = dieta;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public int getTamanio() {
        return tamanio;
    }

    @Override
    public int getPeso() {
        return peso;
    }

    @Override
    public int getVelocidad() {
        return velocidad;
    }

    @Override
    public String getDieta() {
        return dieta;
    }
}

public class Zoologico{

    private List<Animal> animales;

    public Zoologico() {
        animales = new ArrayList<>();
    }

    public void agregarAnimal(Animal animal) {
        animales.add(animal);
    }

    public void consultarAnimales() {
        for(Animal animal : animales) {
            System.out.println(animal.getNombre() + " " + animal.getTamanio() + " "+ animal.getPeso() + " " + animal.getVelocidad() + " " + animal.getDieta());
        }
    }
}

public static void Interfaz (String[] args) {
        Zoologico zoologico = new Zoologico();

        zoologico.agregarAnimal(new Leon("Simba", 2, 200, 50, "carne" ));
        zoologico.agregarAnimal(new Tigre("Bagheera", 3, 300, 60, "carne" ));
        zoologico.agregarAnimal(new Elefante("Dumbo", 5, 5000, 20, "hierba" ));
        zoologico.agregarAnimal(new Jirafa("Rafiki", 4, 1500, 50, "hojas" ));
    }

