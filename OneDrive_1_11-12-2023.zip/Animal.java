public interface Animal{
    public String getNombre();

    public int getTamanio();

    public int getPeso();

    public int getVelocidad();

    public String getDieta();
}