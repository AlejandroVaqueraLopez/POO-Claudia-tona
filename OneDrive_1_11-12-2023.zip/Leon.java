public class Leon implements Animal {
    private String nombre;
    private int tamanio;
    private int peso;
    private int velocidad;
    private String dieta;

    public Leon(String nombre, int tamanio, int peso, int velocidad, String dieta) {
        this.nombre = nombre;
        this.tamanio = tamanio;
        this.peso = peso;
        this.velocidad = velocidad;
        this.dieta = dieta;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public int getTamanio() {
        return tamanio;
    }

    @Override
    public int getPeso() {
        return peso;
    }

    @Override
    public int getVelocidad() {
        return velocidad;
    }

    @Override
    public String getDieta() {
        return dieta;
    }
}